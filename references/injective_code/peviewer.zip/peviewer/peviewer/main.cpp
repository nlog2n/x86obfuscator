/* main.cpp : Defines the entry point for the application.

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Forum:
   http://yodap.sourceforge.net/forum/

   yodap's Site:
   http://yodap.has.it
   http://yodap.cjb.net
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/

//#define  WIN32_LEAN_AND_MEAN
#include "stdafx.h"
#include "main.h"
#include <commdlg.h>
#include <shellapi.h>
#include <windowsx.h>
#include "sectionview.h"
#include "dataview1.h"
#include "dataview2.h"
#include "SubSystem.h"
#include "About.h"
#include ".\16E-FX\16EditDll.h"
#include ".\16E-FX\macros.h"

#pragma comment(linker,"/BASE:0x400000 /FILEALIGN:0x200 /MERGE:.rdata=.text /MERGE:.data=.text /SECTION:.text,EWR /IGNORE:4078")
#pragma pack(1)

#ifdef AP_UNIX_STYLE
   #include <unistd.h>
   #define CB_CALLCONV
#else
   #include <io.h>
   #define AP_HAS_CONIO
   #ifdef AP_DLL
      #define CB_CALLCONV __stdcall
   #else
      #define CB_CALLCONV __cdecl
   #endif
#endif

// Global Variables:

HINSTANCE hInst;	// current instance

HDROP	hDrop;
HICON	hIcon;
HBITMAP	hBitmap;
HWND	hButton;

HWND	hwndMain;		// main application window 
HMENU	hSysMenu;
static HWND	hwndTree;

HACCEL	hAccel;

// Forward declarations of functions included in this code module:
char cFname[256];
char cFnameOpen[256];
char cFnameSave[256];

OPENFILENAME openfn;
OPENFILENAME savefn;
DWORD nFilterIndex=1;
char szCurDir[]=".";
char szFilterOpn[]=TEXT("Executable files (*.exe)\0*.exe\0Dynamic Link Libraries (*.dll)\0*.dll\0OLE-ActiveX Controls (*.ocx)\0*.ocx\0Screen Savers (*.scr)\0*.scr\0All files (*.*)\0*.*\0\0");
char szFilterSave[]=TEXT("All files (*.*)\0*.*\0\0");
char* szAbout = "About...";

PELibrary	*PEfile;
BOOL		bFileOpen=FALSE;

static HE_SETTINGS  s;
static NMTREEVIEW nmTreeView;

LRESULT DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
void OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void OnSysCommand(HWND hwnd, UINT cmd, int x, int y);
void OnDropFiles(HWND hwnd, HDROP hDrop);
void OnPaint (HWND hwnd);
void OnDestroy (HWND hwnd);
void OnClose(HWND hwnd);
LRESULT OnNotify(HWND hwnd,WPARAM wParam,NMHDR* nmheader);

char* IntToHex(DWORD dwValue,UCHAR Num);
void IntToHex2(char* szHEX, DWORD dwValue,UCHAR Num,BOOL HexSign);
HTREEITEM AddItemToTree(HWND hwndTV, LPSTR lpszItem, int nLevel);

typedef struct
{
	int iItem;
	int iSectionNumber;
	int iDirectory;
}t_ITEM_SELECTED;
static t_ITEM_SELECTED ItemSelected;



#define POPMENU_HEXEDIT				1
#define POPMENU_DATAVIEW			2
#define POPMENU_DISASSEMBLER		3
#define POPMENU_SAVEDATA			4
#define POPMENU_SAVEREPORT			5

#define IDC_IMAGE_DOS_HEADER		1
#define IDC_MS_DOS_STUB_PROGRAM		2
#define IDC_IMAGE_NT_HEADERS		3
#define IDC_SIGNATURE				4
#define IDC_IMAGE_FILE_HEADER		5
#define IDC_IMAGE_OPTIONAL_HEADER	6
#define IDC_IMAGE_DATA_DIRECTORY	7
#define IDC_IMAGE_SECTION_HEADERS	8
#define IDC_IMAGE_SECTION_HEADER	9
#define IDC_SECTIONS				10
#define IDC_SECTION					11

static char* szDirectory[16]=
{
	"Export Directory",
	"Import Directory",
	"Resource Directory",
	"Exception Directory",
	"Security Directory",
	"Base Relocation Table",
	"Debug Directory",
	"Architecture Specific Data",
	"RVA of GP", 
	"TLS Directory", 
	"Load Configuration Directory",
	"Bound Import Directory", 
	"Import Address Table", 
	"Delay Load Import Descriptors",
	"COM Runtime descriptor",
	""
};

void FindSelectItem(HWND hwnd,char *szItem)
{
	int i;
	CHAR* szTemp;
	CHAR* szNum;
	ItemSelected.iItem=0;
	ItemSelected.iSectionNumber=0;
	if(!strcmp(szItem,"IMAGE_DOS_HEADER"))
	{
		ItemSelected.iItem=IDC_IMAGE_DOS_HEADER;
	}
	else
	if(!strcmp(szItem,"MS-DOS Stub Program"))
	{
		ItemSelected.iItem=IDC_MS_DOS_STUB_PROGRAM;
	}
	else
	if(!strcmp(szItem,"IMAGE_NT_HEADERS"))
	{
		ItemSelected.iItem=IDC_IMAGE_NT_HEADERS;
	}
	else
	if(!strcmp(szItem,"Signature"))
	{
		ItemSelected.iItem=IDC_SIGNATURE;
	}
	else
	if(!strcmp(szItem,"IMAGE_FILE_HEADER"))
	{
		ItemSelected.iItem=IDC_IMAGE_FILE_HEADER;
	}
	else
	if(!strcmp(szItem,"IMAGE_OPTIONAL_HEADER"))
	{
		ItemSelected.iItem=IDC_IMAGE_OPTIONAL_HEADER;
	}
	else
	if(!strcmp(szItem,"Image Section Headers"))
	{
		ItemSelected.iItem=IDC_IMAGE_SECTION_HEADERS;
	}
	else
	if(!strcmp(szItem,"Sections"))
	{
		ItemSelected.iItem=IDC_SECTIONS;
	}
	szTemp=new CHAR[200];
	szNum=new CHAR[8];
	for(i=0;i<14;i++)
	{
		if(!strcmp(szItem,szDirectory[i]))
		{
			ItemSelected.iDirectory=i;
			ItemSelected.iItem=IDC_IMAGE_DATA_DIRECTORY;
		}
	}
	for(i=0;i<PEfile->image_nt_headers->FileHeader.NumberOfSections;i++)
	{
		strcpy(szTemp,"IMAGE_SECTION_HEADER 0x");
		itoa(i,szNum,16);
		strcat(szTemp,szNum);
		strcat(szTemp,": ");
		strcat(szTemp,(CHAR*)PEfile->image_section_header[i]->Name);
		if(!strcmp(szItem,szTemp))
		{
			ItemSelected.iItem=IDC_IMAGE_SECTION_HEADER;
			ItemSelected.iSectionNumber=i;
		}
	}

	for(i=0;i<PEfile->image_nt_headers->FileHeader.NumberOfSections;i++)
	{
		strcpy(szTemp,"SECTION 0x");
		itoa(i,szNum,16);
		strcat(szTemp,szNum);
		strcat(szTemp,": ");
		strcat(szTemp,(CHAR*)PEfile->image_section_header[i]->Name);
		if(!strcmp(szItem,szTemp))
		{
			ItemSelected.iItem=IDC_SECTION;
			ItemSelected.iSectionNumber=i;
		}
	}
	delete []szTemp;
	delete []szNum;
}

void InsertTable(int iRaw,DWORD dwData, int dataType, DWORD dwBegin, DWORD dwOffset,const char* szDescription, const char* szValue, DWORD add_offset)
{
	IntToHex2(szDataView1[iRaw].szOffset,add_offset+(DWORD)(dwOffset-dwBegin),8,FALSE);
	IntToHex2(szDataView1[iRaw].szData,dwData,dataType,FALSE);
	strcpy(szDataView1[iRaw].szDescription,szDescription);
	strcpy(szDataView1[iRaw].szValue,szValue);
}

void ShowComment(HWND hwnd, int iType)
{
	DWORD dwTemp;
	char* szTemp;
	ZERO(s);
	switch(iType)
	{
	case POPMENU_HEXEDIT:
		s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
						HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
		s.szFilePath   = cFnameOpen;
		break;

	case POPMENU_DATAVIEW:
		break;

	case POPMENU_DISASSEMBLER:
		break;

	case POPMENU_SAVEDATA:
		break;

	case POPMENU_SAVEREPORT:
		break;
	}
	//==================================================================================================================
	switch(ItemSelected.iItem)
	{
	case IDC_IMAGE_DOS_HEADER:
		s.dwSelStartOff=0;
		s.dwSelEndOff=sizeof(IMAGE_DOS_HEADER)-1;
		break;

	case IDC_MS_DOS_STUB_PROGRAM:
		s.dwSelStartOff=sizeof(IMAGE_DOS_HEADER);
		s.dwSelEndOff=PEfile->image_dos_header->e_lfanew-1;
		break;

	case IDC_IMAGE_NT_HEADERS:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew;
		s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_NT_HEADERS)-1;
		break;

	case IDC_SIGNATURE:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew;
		s.dwSelEndOff=s.dwSelStartOff+0x3;
		break;

	case IDC_IMAGE_FILE_HEADER:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+0x4;
		s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_FILE_HEADER)-1;
		break;

	case IDC_IMAGE_OPTIONAL_HEADER:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+0x4+sizeof(IMAGE_FILE_HEADER);
		s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_OPTIONAL_HEADER)-1;
		break;

	case IDC_IMAGE_SECTION_HEADERS:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+sizeof(IMAGE_NT_HEADERS);
		s.dwSelEndOff=s.dwSelStartOff+PEfile->image_nt_headers->FileHeader.NumberOfSections*sizeof(IMAGE_SECTION_HEADER)-1;
		break;

	case IDC_IMAGE_SECTION_HEADER:
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+sizeof(IMAGE_NT_HEADERS)+ItemSelected.iSectionNumber*sizeof(IMAGE_SECTION_HEADER);
		s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_SECTION_HEADER)-1;
		break;

	case IDC_SECTIONS:
		s.dwSelStartOff=PEfile->image_section_header[0]->PointerToRawData;
		s.dwSelEndOff=PEfile->image_section_header[PEfile->image_nt_headers->FileHeader.NumberOfSections-1]->PointerToRawData
			+PEfile->image_section_header[PEfile->image_nt_headers->FileHeader.NumberOfSections-1]->SizeOfRawData-1;
		break;

	case IDC_SECTION:
		s.dwSelStartOff=PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData;
		s.dwSelEndOff=PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData+PEfile->image_section_header[ItemSelected.iSectionNumber]->SizeOfRawData-1;
		break;
	}
	//==================================================================================================================
	switch(iType)
	{
	case POPMENU_HEXEDIT:
		if(PEfile->dwFileSize<=s.dwSelEndOff) s.dwSelEndOff=PEfile->dwFileSize-1;
		if(s.dwSelStartOff>=s.dwSelEndOff)
		{
				s.dwMask&=~ HE_SET_SETSELECTION;
				s.dwMask|=  HE_SET_SETCURRENTOFFSET;
				s.posCaret.dwOffset=s.dwSelStartOff;
				if(PEfile->dwFileSize<=s.posCaret.dwOffset) s.posCaret.dwOffset=PEfile->dwFileSize-1;
		}
		if (!HESpecifySettings(&s))
		{
			MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
			return;; // ERR
		}
		HEEnterWindowLoop();
		break;

	case POPMENU_DATAVIEW:
		switch(ItemSelected.iItem)
		{
		case IDC_IMAGE_DOS_HEADER:
			s.dwSelStartOff=0;
			s.dwSelEndOff=sizeof(IMAGE_DOS_HEADER)-1;
			iDataView1=31;
			szDataView1=new DATAVIEW[iDataView1];
			InsertTable(0,PEfile->image_dos_header->e_magic, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_magic),
				"e_magic", "Magic number",0);
			InsertTable(1,PEfile->image_dos_header->e_cblp, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_cblp),
				"e_cblp", "Bytes on last page of file",0);
			InsertTable(2,PEfile->image_dos_header->e_cp, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_cp),
				"e_cp", "Pages in file",0);
			InsertTable(3,PEfile->image_dos_header->e_crlc, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_crlc),
				"e_crlc", "Relocations",0);
			InsertTable(4,PEfile->image_dos_header->e_cparhdr, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_cparhdr),
				"e_cparhdr", "Size of header in paragraphs",0);
			InsertTable(5,PEfile->image_dos_header->e_minalloc, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_minalloc),
				"e_minalloc", "Minimum extra paragraphs needed",0);
			InsertTable(6,PEfile->image_dos_header->e_maxalloc, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_maxalloc),
				"e_maxalloc", "Maximum extra paragraphs needed",0);
			InsertTable(7,PEfile->image_dos_header->e_ss, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_ss),
				"e_ss", "Initial (relative) SS value",0);
			InsertTable(8,PEfile->image_dos_header->e_sp, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_sp),
				"e_sp", "Initial SP value",0);
			InsertTable(9,PEfile->image_dos_header->e_csum, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_csum),
				"e_csum", "Checksum",0);
			InsertTable(10,PEfile->image_dos_header->e_ip, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_ip),
				"e_ip", "Initial IP value",0);
			InsertTable(11,PEfile->image_dos_header->e_cs, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_cs),
				"e_cs", "Initial (relative) CS value",0);
			InsertTable(12,PEfile->image_dos_header->e_lfarlc, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_lfarlc),
				"e_lfarlc", "File address of relocation table",0);
			InsertTable(13,PEfile->image_dos_header->e_ovno, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_ovno),
				"e_ovno", "Overlay number",0);
			InsertTable(14,PEfile->image_dos_header->e_res[0], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res[0]),
				"e_res[0]", "Reserved words",0);
			InsertTable(15,PEfile->image_dos_header->e_res[1], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res[1]),
				"e_res[1]", "Reserved words",0);
			InsertTable(16,PEfile->image_dos_header->e_res[2], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res[2]),
				"e_res[2]", "Reserved words",0);
			InsertTable(17,PEfile->image_dos_header->e_res[3], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res[3]),
				"e_res[3]", "Reserved words",0);
			InsertTable(18,PEfile->image_dos_header->e_oemid, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_oemid),
				"e_oemid", "OEM identifier (for e_oeminfo)",0);
			InsertTable(19,PEfile->image_dos_header->e_oeminfo, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_oeminfo),
				"e_oeminfo", "OEM information; e_oemid specific",0);
			InsertTable(20,PEfile->image_dos_header->e_res2[0], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[0]),
				"e_res2[0]", "Reserved words",0);
			InsertTable(21,PEfile->image_dos_header->e_res2[1], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[1]),
				"e_res2[1]", "Reserved words",0);
			InsertTable(22,PEfile->image_dos_header->e_res2[2], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[2]),
				"e_res2[2]", "Reserved words",0);
			InsertTable(23,PEfile->image_dos_header->e_res2[3], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[3]),
				"e_res2[3]", "Reserved words",0);
			InsertTable(24,PEfile->image_dos_header->e_res2[4], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[4]),
				"e_res2[4]", "Reserved words",0);
			InsertTable(25,PEfile->image_dos_header->e_res2[5], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[5]),
				"e_res2[5]", "Reserved words",0);
			InsertTable(26,PEfile->image_dos_header->e_res2[6], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[6]),
				"e_res2[6]", "Reserved words",0);
			InsertTable(27,PEfile->image_dos_header->e_res2[7], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[7]),
				"e_res2[7]", "Reserved words",0);
			InsertTable(28,PEfile->image_dos_header->e_res2[8], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[8]),
				"e_res2[8]", "Reserved words",0);
			InsertTable(29,PEfile->image_dos_header->e_res2[9], 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_res2[9]),
				"e_res2[9]", "Reserved words",0);
			InsertTable(30,PEfile->image_dos_header->e_lfanew, 4, 
				(DWORD)((DWORD64)&PEfile->image_dos_header), 
				(DWORD)((DWORD64)&PEfile->image_dos_header->e_lfanew),
				"e_lfanew", "File address of new exe header",0);
			DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView1);
			delete []szDataView1;
			break;

		case IDC_IMAGE_FILE_HEADER:
			s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+0x4;
			s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_FILE_HEADER)-1;
			iDataView1=7;
			szDataView1=new DATAVIEW[iDataView1];
			InsertTable(0,PEfile->image_nt_headers->FileHeader.Machine, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.Machine),
				"Machine", "",s.dwSelStartOff);
			InsertTable(1,PEfile->image_nt_headers->FileHeader.NumberOfSections, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.NumberOfSections),
				"NumberOfSections", "",s.dwSelStartOff);
			InsertTable(2,PEfile->image_nt_headers->FileHeader.TimeDateStamp, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.TimeDateStamp),
				"TimeDateStamp", "",s.dwSelStartOff);
			InsertTable(3,PEfile->image_nt_headers->FileHeader.PointerToSymbolTable, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.PointerToSymbolTable),
				"PointerToSymbolTable", "",s.dwSelStartOff);
			InsertTable(4,PEfile->image_nt_headers->FileHeader.NumberOfSymbols, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.NumberOfSymbols),
				"NumberOfSymbols", "",s.dwSelStartOff);
			InsertTable(5,PEfile->image_nt_headers->FileHeader.SizeOfOptionalHeader, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.SizeOfOptionalHeader),
				"SizeOfOptionalHeader", "",s.dwSelStartOff);
			InsertTable(6,PEfile->image_nt_headers->FileHeader.Characteristics, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->FileHeader.Characteristics),
				"Characteristics", "",s.dwSelStartOff);
			DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView1);
			delete []szDataView1;
			break;

		case IDC_IMAGE_OPTIONAL_HEADER:
			s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+0x4+sizeof(IMAGE_FILE_HEADER);
			s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_OPTIONAL_HEADER)-1;
			iDataView1=62;
			szDataView1=new DATAVIEW[iDataView1];
			InsertTable(0,PEfile->image_nt_headers->OptionalHeader.Magic, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.Magic),
				"Magic", "",s.dwSelStartOff);
			InsertTable(1,PEfile->image_nt_headers->OptionalHeader.MajorLinkerVersion, 2, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MajorLinkerVersion),
				"MajorLinkerVersion", "",s.dwSelStartOff);
			InsertTable(2,PEfile->image_nt_headers->OptionalHeader.MinorLinkerVersion, 2, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MinorLinkerVersion),
				"MinorLinkerVersion", "",s.dwSelStartOff);
			InsertTable(3,PEfile->image_nt_headers->OptionalHeader.SizeOfCode, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfCode),
				"SizeOfCode", "",s.dwSelStartOff);
			InsertTable(4,PEfile->image_nt_headers->OptionalHeader.SizeOfInitializedData, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfInitializedData),
				"SizeOfInitializedData", "",s.dwSelStartOff);
			InsertTable(5,PEfile->image_nt_headers->OptionalHeader.SizeOfUninitializedData, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfUninitializedData),
				"SizeOfUninitializedData", "",s.dwSelStartOff);
			InsertTable(6,PEfile->image_nt_headers->OptionalHeader.AddressOfEntryPoint, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.AddressOfEntryPoint),
				"AddressOfEntryPoint", "",s.dwSelStartOff);
			InsertTable(7,PEfile->image_nt_headers->OptionalHeader.BaseOfCode, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.BaseOfCode),
				"BaseOfCode", "",s.dwSelStartOff);
			InsertTable(8,PEfile->image_nt_headers->OptionalHeader.BaseOfData, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.BaseOfData),
				"BaseOfData", "",s.dwSelStartOff);
			InsertTable(9,PEfile->image_nt_headers->OptionalHeader.ImageBase, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.ImageBase),
				"ImageBase", "",s.dwSelStartOff);
			InsertTable(10,PEfile->image_nt_headers->OptionalHeader.SectionAlignment, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SectionAlignment),
				"SectionAlignment", "",s.dwSelStartOff);
			InsertTable(11,PEfile->image_nt_headers->OptionalHeader.FileAlignment, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.FileAlignment),
				"FileAlignment", "",s.dwSelStartOff);
			InsertTable(12,PEfile->image_nt_headers->OptionalHeader.MajorOperatingSystemVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MajorOperatingSystemVersion),
				"MajorOperatingSystemVersion", "",s.dwSelStartOff);
			InsertTable(13,PEfile->image_nt_headers->OptionalHeader.MinorOperatingSystemVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MinorOperatingSystemVersion),
				"MinorOperatingSystemVersion", "",s.dwSelStartOff);
			InsertTable(14,PEfile->image_nt_headers->OptionalHeader.MajorImageVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MajorImageVersion),
				"MajorImageVersion", "",s.dwSelStartOff);
			InsertTable(15,PEfile->image_nt_headers->OptionalHeader.MinorImageVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MinorImageVersion),
				"MinorImageVersion", "",s.dwSelStartOff);
			InsertTable(16,PEfile->image_nt_headers->OptionalHeader.MajorSubsystemVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MajorSubsystemVersion),
				"MajorSubsystemVersion", "",s.dwSelStartOff);
			InsertTable(17,PEfile->image_nt_headers->OptionalHeader.MinorSubsystemVersion, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.MinorSubsystemVersion),
				"MinorSubsystemVersion", "",s.dwSelStartOff);
			InsertTable(18,PEfile->image_nt_headers->OptionalHeader.Win32VersionValue, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.Win32VersionValue),
				"Win32VersionValue", "",s.dwSelStartOff);
			InsertTable(19,PEfile->image_nt_headers->OptionalHeader.SizeOfImage, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfImage),
				"SizeOfImage", "",s.dwSelStartOff);
			InsertTable(20,PEfile->image_nt_headers->OptionalHeader.SizeOfHeaders, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfHeaders),
				"SizeOfHeaders", "",s.dwSelStartOff);
			InsertTable(21,PEfile->image_nt_headers->OptionalHeader.CheckSum, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.CheckSum),
				"CheckSum", "",s.dwSelStartOff);
			InsertTable(22,PEfile->image_nt_headers->OptionalHeader.Subsystem, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.Subsystem),
				"Subsystem", "",s.dwSelStartOff);
			InsertTable(23,PEfile->image_nt_headers->OptionalHeader.DllCharacteristics, 4, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DllCharacteristics),
				"DllCharacteristics", "",s.dwSelStartOff);
			InsertTable(24,PEfile->image_nt_headers->OptionalHeader.SizeOfStackReserve, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfStackReserve),
				"SizeOfStackReserve", "",s.dwSelStartOff);
			InsertTable(25,PEfile->image_nt_headers->OptionalHeader.SizeOfStackCommit, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfStackCommit),
				"SizeOfStackCommit", "",s.dwSelStartOff);
			InsertTable(26,PEfile->image_nt_headers->OptionalHeader.SizeOfHeapReserve, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfHeapReserve),
				"SizeOfHeapReserve", "",s.dwSelStartOff);
			InsertTable(27,PEfile->image_nt_headers->OptionalHeader.SizeOfHeapCommit, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.SizeOfHeapCommit),
				"SizeOfHeapCommit", "",s.dwSelStartOff);
			InsertTable(28,PEfile->image_nt_headers->OptionalHeader.LoaderFlags, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.LoaderFlags),
				"LoaderFlags", "",s.dwSelStartOff);
			InsertTable(29,PEfile->image_nt_headers->OptionalHeader.NumberOfRvaAndSizes, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.NumberOfRvaAndSizes),
				"NumberOfRvaAndSizes", "",s.dwSelStartOff);
			InsertTable(30,PEfile->image_nt_headers->OptionalHeader.DataDirectory[0].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[0].VirtualAddress),
				"DataDirectory[0].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_EXPORT",s.dwSelStartOff);
			InsertTable(31,PEfile->image_nt_headers->OptionalHeader.DataDirectory[0].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[0].Size),
				"DataDirectory[0].Size", "",s.dwSelStartOff);
			InsertTable(32,PEfile->image_nt_headers->OptionalHeader.DataDirectory[1].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[1].VirtualAddress),
				"DataDirectory[1].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_IMPORT",s.dwSelStartOff);
			InsertTable(33,PEfile->image_nt_headers->OptionalHeader.DataDirectory[1].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[1].Size),
				"DataDirectory[1].Size", "",s.dwSelStartOff);
			InsertTable(34,PEfile->image_nt_headers->OptionalHeader.DataDirectory[2].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[2].VirtualAddress),
				"DataDirectory[2].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_RESOURCE",s.dwSelStartOff);
			InsertTable(35,PEfile->image_nt_headers->OptionalHeader.DataDirectory[2].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[2].Size),
				"DataDirectory[2].Size", "",s.dwSelStartOff);
			InsertTable(36,PEfile->image_nt_headers->OptionalHeader.DataDirectory[3].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[3].VirtualAddress),
				"DataDirectory[3].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_EXCEPTION",s.dwSelStartOff);
			InsertTable(37,PEfile->image_nt_headers->OptionalHeader.DataDirectory[3].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[3].Size),
				"DataDirectory[3].Size", "",s.dwSelStartOff);
			InsertTable(38,PEfile->image_nt_headers->OptionalHeader.DataDirectory[4].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[4].VirtualAddress),
				"DataDirectory[4].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_SECURITY",s.dwSelStartOff);
			InsertTable(39,PEfile->image_nt_headers->OptionalHeader.DataDirectory[4].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[4].Size),
				"DataDirectory[4].Size", "",s.dwSelStartOff);
			InsertTable(40,PEfile->image_nt_headers->OptionalHeader.DataDirectory[5].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[5].VirtualAddress),
				"DataDirectory[5].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_BASERELOC",s.dwSelStartOff);
			InsertTable(41,PEfile->image_nt_headers->OptionalHeader.DataDirectory[5].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[5].Size),
				"DataDirectory[5].Size", "",s.dwSelStartOff);
			InsertTable(42,PEfile->image_nt_headers->OptionalHeader.DataDirectory[6].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[6].VirtualAddress),
				"DataDirectory[6].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_DEBUG",s.dwSelStartOff);
			InsertTable(43,PEfile->image_nt_headers->OptionalHeader.DataDirectory[6].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[6].Size),
				"DataDirectory[6].Size", "",s.dwSelStartOff);
			InsertTable(44,PEfile->image_nt_headers->OptionalHeader.DataDirectory[7].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[7].VirtualAddress),
				"DataDirectory[7].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_ARCHITECTURE",s.dwSelStartOff);
			InsertTable(45,PEfile->image_nt_headers->OptionalHeader.DataDirectory[7].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[7].Size),
				"DataDirectory[7].Size", "",s.dwSelStartOff);
			InsertTable(46,PEfile->image_nt_headers->OptionalHeader.DataDirectory[8].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[8].VirtualAddress),
				"DataDirectory[8].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_GLOBALPTR",s.dwSelStartOff);
			InsertTable(47,PEfile->image_nt_headers->OptionalHeader.DataDirectory[8].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[8].Size),
				"DataDirectory[8].Size", "",s.dwSelStartOff);
			InsertTable(48,PEfile->image_nt_headers->OptionalHeader.DataDirectory[9].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[9].VirtualAddress),
				"DataDirectory[9].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_TLS",s.dwSelStartOff);
			InsertTable(49,PEfile->image_nt_headers->OptionalHeader.DataDirectory[9].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[9].Size),
				"DataDirectory[9].Size", "",s.dwSelStartOff);
			InsertTable(50,PEfile->image_nt_headers->OptionalHeader.DataDirectory[10].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[10].VirtualAddress),
				"DataDirectory[10].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG ",s.dwSelStartOff);
			InsertTable(51,PEfile->image_nt_headers->OptionalHeader.DataDirectory[10].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[10].Size),
				"DataDirectory[10].Size", "",s.dwSelStartOff);
			InsertTable(52,PEfile->image_nt_headers->OptionalHeader.DataDirectory[11].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[11].VirtualAddress),
				"DataDirectory[11].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT",s.dwSelStartOff);
			InsertTable(53,PEfile->image_nt_headers->OptionalHeader.DataDirectory[11].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[11].Size),
				"DataDirectory[11].Size", "",s.dwSelStartOff);
			InsertTable(54,PEfile->image_nt_headers->OptionalHeader.DataDirectory[12].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[12].VirtualAddress),
				"DataDirectory[12].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_IAT",s.dwSelStartOff);
			InsertTable(55,PEfile->image_nt_headers->OptionalHeader.DataDirectory[12].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[12].Size),
				"DataDirectory[12].Size", "",s.dwSelStartOff);
			InsertTable(56,PEfile->image_nt_headers->OptionalHeader.DataDirectory[13].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[13].VirtualAddress),
				"DataDirectory[13].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT",s.dwSelStartOff);
			InsertTable(57,PEfile->image_nt_headers->OptionalHeader.DataDirectory[13].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[13].Size),
				"DataDirectory[13].Size", "",s.dwSelStartOff);
			InsertTable(58,PEfile->image_nt_headers->OptionalHeader.DataDirectory[14].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[14].VirtualAddress),
				"DataDirectory[14].VirtualAddress", "IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR",s.dwSelStartOff);
			InsertTable(59,PEfile->image_nt_headers->OptionalHeader.DataDirectory[14].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[14].Size),
				"DataDirectory[14].Size", "",s.dwSelStartOff);
			InsertTable(60,PEfile->image_nt_headers->OptionalHeader.DataDirectory[15].VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[15].VirtualAddress),
				"DataDirectory[15].VirtualAddress", "",s.dwSelStartOff);
			InsertTable(61,PEfile->image_nt_headers->OptionalHeader.DataDirectory[15].Size, 8, 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader), 
				(DWORD)((DWORD64)&PEfile->image_nt_headers->OptionalHeader.DataDirectory[15].Size),
				"DataDirectory[15].Size", "",s.dwSelStartOff);
			DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView1);
			delete []szDataView1;
			break;

		case IDC_IMAGE_DATA_DIRECTORY:
			switch(ItemSelected.iDirectory)
			{
			case IMAGE_DIRECTORY_ENTRY_EXPORT:			// Export Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_IMPORT:			// Import Directory
				//DialogBox(hInst, (LPCTSTR)IDD_IMPORT_TABLE, hwnd, (DLGPROC)ImportTableView);
				break;

			case IMAGE_DIRECTORY_ENTRY_RESOURCE:		// Resource Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_EXCEPTION:		// Exception Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_SECURITY:		// Security Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_BASERELOC:		// Base Relocation Table
				break;

			case IMAGE_DIRECTORY_ENTRY_DEBUG:			// Debug Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_ARCHITECTURE:	// Architecture Specific Data
				break;

			case IMAGE_DIRECTORY_ENTRY_GLOBALPTR:		// RVA of GP
				break;

			case IMAGE_DIRECTORY_ENTRY_TLS:				// TLS Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG:		// Load Configuration Directory
				break;

			case IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT:	// Bound Import Directory in headers
				break;

			case IMAGE_DIRECTORY_ENTRY_IAT:				// Import Address Table
				break;

			case IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT:	// Delay Load Import Descriptors
				break;

			case IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR:	// COM Runtime descriptor
				break;
			}
			break;


		case IDC_IMAGE_SECTION_HEADER:
			s.dwSelStartOff=PEfile->image_dos_header->e_lfanew+sizeof(IMAGE_NT_HEADERS)+ItemSelected.iSectionNumber*sizeof(IMAGE_SECTION_HEADER);
			s.dwSelEndOff=s.dwSelStartOff+sizeof(IMAGE_SECTION_HEADER)-1;
			iDataView1=11;
			szDataView1=new DATAVIEW[iDataView1];
			szTemp=new CHAR[9];
			memset(szTemp,0x0,9);
			memcpy(szTemp,&PEfile->image_section_header[ItemSelected.iSectionNumber]->Name,8);
			memcpy(&dwTemp,&PEfile->image_section_header[ItemSelected.iSectionNumber]->Name[0],4);
			InsertTable(0,dwTemp, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->Name[0]),
				"Name",szTemp,s.dwSelStartOff);
			memcpy(&dwTemp,&PEfile->image_section_header[ItemSelected.iSectionNumber]->Name[4],4);
			InsertTable(1,dwTemp, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->Name[4]),
				"", "",s.dwSelStartOff);
			InsertTable(2,PEfile->image_section_header[ItemSelected.iSectionNumber]->Misc.VirtualSize, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->Misc.VirtualSize),
				"VirtualSize", "",s.dwSelStartOff);
			InsertTable(3,PEfile->image_section_header[ItemSelected.iSectionNumber]->VirtualAddress, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->VirtualAddress),
				"VirtualAddress", "",s.dwSelStartOff);
			InsertTable(4,PEfile->image_section_header[ItemSelected.iSectionNumber]->SizeOfRawData, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->SizeOfRawData),
				"SizeOfRawData", "",s.dwSelStartOff);
			InsertTable(5,PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData),
				"PointerToRawData", "",s.dwSelStartOff);
			InsertTable(6,PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRelocations, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRelocations),
				"PointerToRelocations", "",s.dwSelStartOff);
			InsertTable(7,PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToLinenumbers, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToLinenumbers),
				"PointerToLinenumbers", "",s.dwSelStartOff);
			InsertTable(8,PEfile->image_section_header[ItemSelected.iSectionNumber]->NumberOfRelocations, 4, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->NumberOfRelocations),
				"NumberOfRelocations", "",s.dwSelStartOff);
			InsertTable(9,PEfile->image_section_header[ItemSelected.iSectionNumber]->NumberOfLinenumbers, 4, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->NumberOfLinenumbers),
				"NumberOfLinenumbers", "",s.dwSelStartOff);
			InsertTable(10,PEfile->image_section_header[ItemSelected.iSectionNumber]->Characteristics, 8, 
				(DWORD)((DWORD64)&PEfile->image_section_header[0]), 
				(DWORD)((DWORD64)&PEfile->image_section_header[ItemSelected.iSectionNumber]->Characteristics),
				"Characteristics", "",s.dwSelStartOff);
			DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView1);
			delete []szTemp;
			delete []szDataView1;
			break;
		}

		break;

	case POPMENU_DISASSEMBLER:
		break;

	case POPMENU_SAVEDATA:
		break;

	case POPMENU_SAVEREPORT:
		break;
	}
/*	switch(ItemSelected.iItem)
	{
	case IDC_IMAGE_DOS_HEADER:
		DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView1);
		break;

	case IDC_MS_DOS_STUB_PROGRAM:
		//DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView2);
		ZERO(s);
		s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
						HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
		s.szFilePath   = cFnameOpen;
		if(sizeof(IMAGE_DOS_HEADER)<PEfile->image_dos_header->e_lfanew)
		{
			s.dwSelStartOff=sizeof(IMAGE_DOS_HEADER);
			s.dwSelEndOff=PEfile->image_dos_header->e_lfanew-1;
		}
		else
		{
			s.dwMask&=~ HE_SET_SETSELECTION;
		}
		
		if (!HESpecifySettings(&s))
		{
			MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
			return;; // ERR
		}
		HEEnterWindowLoop();
		break;

	case IDC_IMAGE_NT_HEADERS:
		//DialogBox(hInst, (LPCTSTR)IDD_DATAVIEW1, hwnd, (DLGPROC)DataView2);
		ZERO(s);
		s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
						HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
		s.szFilePath   = cFnameOpen;
		s.dwSelStartOff=PEfile->image_dos_header->e_lfanew;
		s.dwSelEndOff=PEfile->image_dos_header->e_lfanew+sizeof(IMAGE_NT_HEADERS);
		if (!HESpecifySettings(&s))
		{
			MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
			return;; // ERR
		}
		HEEnterWindowLoop();
		break;

	case IDC_IMAGE_SECTION_HEADERS:
	case IDC_SECTIONS:
		DialogBox(hInst, (LPCTSTR)IDD_SECTIONVIEW, hwnd, (DLGPROC)SectionView);
		break;

	case IDC_IMAGE_SECTION_HEADER:
		break;

	case IDC_SECTION:
		ZERO(s);
		if(PEfile->image_section_header[ItemSelected.iSectionNumber]->SizeOfRawData!=0)
		{
			s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
							HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
			s.szFilePath   = cFnameOpen;
			s.dwSelStartOff=PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData;
			s.dwSelEndOff=PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData+PEfile->image_section_header[ItemSelected.iSectionNumber]->SizeOfRawData-1;
			if(PEfile->dwFileSize<=s.dwSelEndOff) s.dwSelEndOff=PEfile->dwFileSize-1;
		}
		else
		{
			s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
							HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETCURRENTOFFSET;
			s.szFilePath   = cFnameOpen;
			s.posCaret.dwOffset=PEfile->image_section_header[ItemSelected.iSectionNumber]->PointerToRawData;
			if(PEfile->dwFileSize<=s.posCaret.dwOffset) s.posCaret.dwOffset=PEfile->dwFileSize-1;
		}

		if (!HESpecifySettings(&s))
		{
			MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
			break; // ERR
		}
		HEEnterWindowLoop();
		break;
	}*/
}

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	hInst=GetModuleHandle(0);

	DialogBoxParam(hInst,MAKEINTRESOURCE(IDD_MAINDLG),0,(DLGPROC)DlgProc,0);
	//DoPropertySheet(hInst);
	ExitProcess(0);
	return (int) msg.wParam;
}

void EnableItems(HWND hDlg)
{
	hButton=GetDlgItem(hDlg,IDC_STATIC1); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_PASSWORD); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_STATIC2); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_ALG_ID); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_ENCRYPT); 
	EnableWindow(hButton,TRUE);
	hButton=GetDlgItem(hDlg,IDC_DECRYPT); 
	EnableWindow(hButton,TRUE);
}

char szHEXtemp[12];
char szHEXtemp2[12];
char* IntToHex(DWORD dwValue,UCHAR Num,BOOL HexSign)
{
	int i;
	FillMemory(szHEXtemp,sizeof(szHEXtemp),0x00);
	if(HexSign)
	{
		for(i=0;i<Num+2;i++)szHEXtemp[i]='0';
		szHEXtemp[1]='x';
		switch(Num)
		{
		case 2:_itoa(UCHAR(dwValue),szHEXtemp2,16);break;
		case 4:_itoa(WORD(dwValue),szHEXtemp2,16);break;
		case 8:_itoa(DWORD(dwValue),szHEXtemp2,16);break;
		}
		int l=(int)strlen(szHEXtemp2);
		CharUpperBuff(szHEXtemp2,l);
		CopyMemory(szHEXtemp+Num+2-l,szHEXtemp2,l);
	}
	else
	{
		for(i=0;i<Num;i++)szHEXtemp[i]='0';
		switch(Num)
		{
		case 2:_itoa(UCHAR(dwValue),szHEXtemp2,16);break;
		case 4:_itoa(WORD(dwValue),szHEXtemp2,16);break;
		case 8:_itoa(DWORD(dwValue),szHEXtemp2,16);break;
		}
		int l=(int)strlen(szHEXtemp2);
		CharUpperBuff(szHEXtemp2,l);
		CopyMemory(szHEXtemp+Num-l,szHEXtemp2,l);
	}
	return(szHEXtemp);
}
void IntToHex2(char* szHEX, DWORD dwValue,UCHAR Num,BOOL HexSign)
{
	int i;
	char ch;
	int l;
	FillMemory(szHEX,sizeof(szHEX),0x00);
	if(HexSign)
	{
		for(i=0;i<Num+2;i++)szHEX[i]='0';
		szHEX[1]='x';
		switch(Num)
		{
		case 2:_itoa(UCHAR(dwValue),szHEXtemp2,16);break;
		case 4:_itoa(WORD(dwValue),szHEXtemp2,16);break;
		case 8:_itoa(DWORD(dwValue),szHEXtemp2,16);break;
		}
		l=(int)strlen(szHEXtemp2);
		CharUpperBuff(szHEXtemp2,l);
		CopyMemory(szHEX+Num+2-l,szHEXtemp2,l);
	}
	else
	{
		for(i=0;i<Num;i++)szHEX[i]='0';
		switch(Num)
		{
		case 2:_itoa(UCHAR(dwValue),szHEXtemp2,16);break;
		case 4:_itoa(WORD(dwValue),szHEXtemp2,16);break;
		case 8:_itoa(DWORD(dwValue),szHEXtemp2,16);break;
		}
		l=(int)strlen(szHEXtemp2);
		CharUpperBuff(szHEXtemp2,l);
		CopyMemory(szHEX+Num-l,szHEXtemp2,l);
	}
	ch=0x0;
	CopyMemory(szHEX+Num,&ch,1);
}

char szTmp[32];
char szTmp1[12];
char* szLinkerInfo(UCHAR chMajor,UCHAR chMinor)
{
	_itoa(chMinor,szTmp1,10);
	_itoa(chMajor,szTmp,10);
	strcat(szTmp,".");
	strcat(szTmp,szTmp1);
	return(szTmp);
}

char* szFirstBytes(char* szMem)
{
	int i;
	strcpy(szTmp,"");
	for(i=0;i<4;i++)
	{
		strcat(szTmp,IntToHex(szMem[i],2,FALSE));
		if(i!=3)strcat(szTmp,",");
	}
	return(szTmp);
}

char* szSubSystem(WORD wSubSystem)
{
	switch(wSubSystem)
	{
	case IMAGE_SUBSYSTEM_UNKNOWN:// Unknown subsystem.
		strcpy(szTmp,"unknown");
		break;

	case IMAGE_SUBSYSTEM_NATIVE:// Image doesn't require a subsystem.
		strcpy(szTmp,"Native");
		break;

	case IMAGE_SUBSYSTEM_WINDOWS_GUI:// Image runs in the Windows GUI subsystem.
		strcpy(szTmp,"Win32 GUI");
		break;

	case IMAGE_SUBSYSTEM_WINDOWS_CUI:// Image runs in the Windows character subsystem.
		strcpy(szTmp,"Win32 console");
		break;

	case IMAGE_SUBSYSTEM_OS2_CUI:// image runs in the OS/2 character subsystem.
		strcpy(szTmp,"OS2 console");
		break;

	case IMAGE_SUBSYSTEM_POSIX_CUI:// image runs in the Posix character subsystem.
		strcpy(szTmp,"Posix console");
		break;

	case IMAGE_SUBSYSTEM_NATIVE_WINDOWS:// image is a native Win9x driver.
		strcpy(szTmp,"Native Win9x");
		break;

	case IMAGE_SUBSYSTEM_WINDOWS_CE_GUI:// Image runs in the Windows CE subsystem.
		strcpy(szTmp,"WinCE GUI");
		break;

	case IMAGE_SUBSYSTEM_EFI_APPLICATION://
		strcpy(szTmp,"WinCE GUI");
		break;

	case IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER://
		strcpy(szTmp,"EFI boot");
		break;

	case IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER:
		strcpy(szTmp,"EFI Runtime");
		break;

	case IMAGE_SUBSYSTEM_EFI_ROM:
		strcpy(szTmp,"EFI ROM");
		break;

	case IMAGE_SUBSYSTEM_XBOX:
		strcpy(szTmp,"XBOX");
		break;
	}
	return(szTmp);
}
void UpdateItems(HWND hDlg)
{
	SetDlgItemText(hDlg,IDC_OEP,IntToHex(PEfile->image_nt_headers->OptionalHeader.AddressOfEntryPoint,8,TRUE));
	SetDlgItemText(hDlg,IDC_ROOEP,IntToHex(PEfile->ROAddressOfEntryPoint,8,TRUE));
	SetDlgItemText(hDlg,IDC_LINKINFO,szLinkerInfo(PEfile->image_nt_headers->OptionalHeader.MajorLinkerVersion,PEfile->image_nt_headers->OptionalHeader.MinorLinkerVersion));
	//
	SetDlgItemText(hDlg,IDC_EPSECTION,(LPCSTR)PEfile->image_section_header[PEfile->EPSectionNum]->Name);	
	SetDlgItemText(hDlg,IDC_FIRSTBYTES,szFirstBytes(PEfile->FirstBytes));
	SetDlgItemText(hDlg,IDC_SUBSYSTEM,szSubSystem(PEfile->image_nt_headers->OptionalHeader.Subsystem));

}
// internal helpers
// 
static void FrameWindow(HWND hWnd)
{
	if (!IsWindow(hWnd)) return;

	RECT wndRect;
	GetWindowRect(hWnd,&wndRect);
	//   wndRect.NormalizeRect();
	SetRect(&wndRect,0,0,
		wndRect.right - wndRect.left,
		wndRect.bottom - wndRect.top);

	HDC      hDC;
	int      iOldROP;
	HPEN     hPen;
	HPEN     hOldPen;
	HBRUSH   hOldBrush;

	hDC = GetWindowDC(hWnd);
	iOldROP = SetROP2(hDC, R2_XORPEN);
	hPen = CreatePen(PS_SOLID, GetSystemMetrics(SM_CXSIZEFRAME), RGB(255, 255, 255));
	hOldPen = (HPEN)SelectObject(hDC, hPen);
	hOldBrush = (HBRUSH)SelectObject(hDC, GetStockObject(NULL_BRUSH));

	Rectangle(hDC, wndRect.left, wndRect.top, wndRect.right, wndRect.bottom);
   
	SelectObject(hDC, hOldBrush);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
	SetROP2(hDC, iOldROP);
	ReleaseDC(hWnd, hDC);
}

// AddItemToTree - adds items to a tree-view control. 
// Returns the handle to the newly added item. 
// hwndTV - handle to the tree-view control. 
// lpszItem - text of the item to add. 
// nLevel - level at which to add the item. 

HTREEITEM AddItemToTree(HWND hwndTV, LPSTR lpszItem, int nLevel)
{ 
    TVITEM tvi; 
    TVINSERTSTRUCT tvins; 
    static HTREEITEM hPrev = (HTREEITEM)TVI_FIRST; 
    static HTREEITEM hPrevRootItem = NULL; 
    static HTREEITEM hPrevLev2Item = NULL; 
    HTREEITEM hti; 

    tvi.mask = TVIF_TEXT | TVIF_IMAGE 
               | TVIF_SELECTEDIMAGE | TVIF_PARAM; 

    // Set the text of the item. 
    tvi.pszText = lpszItem; 
    tvi.cchTextMax = sizeof(tvi.pszText)/sizeof(tvi.pszText[0]); 

    // Assume the item is not a parent item, so give it a 
    // document image. 
//    tvi.iImage = g_nDocument; 
 //   tvi.iSelectedImage = g_nDocument; 

    // Save the heading level in the item's application-defined 
    // data area. 
    tvi.lParam = (LPARAM)nLevel; 
    tvins.item = tvi; 
    tvins.hInsertAfter = hPrev; 

    // Set the parent item based on the specified level. 
    if (nLevel == 1) 
        tvins.hParent = TVI_ROOT; 
    else if (nLevel == 2) 
        tvins.hParent = hPrevRootItem; 
    else 
        tvins.hParent = hPrevLev2Item; 

    // Add the item to the tree-view control. 
    hPrev = (HTREEITEM)SendMessage(hwndTV, 
                                   TVM_INSERTITEM, 
                                   0,
                                   (LPARAM)(LPTVINSERTSTRUCT)&tvins); 

    // Save the handle to the item. 
    if (nLevel == 1) 
        hPrevRootItem = hPrev; 
    else if (nLevel == 2) 
        hPrevLev2Item = hPrev; 

    // The new item is a child item. Give the parent item a 
    // closed folder bitmap to indicate it now has child items. 
    if (nLevel > 1)
    { 
        hti = TreeView_GetParent(hwndTV, hPrev); 
        tvi.mask = TVIF_IMAGE | TVIF_SELECTEDIMAGE; 
        tvi.hItem = hti; 
//        tvi.iImage = g_nClosed; 
//        tvi.iSelectedImage = g_nClosed; 
        TreeView_SetItem(hwndTV, &tvi); 
    } 

    return hPrev; 
} 

//  FUNCTION: DlgProc(HWND, unsigned, WORD, LONG)
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LRESULT DlgProc(HWND hDlg,UINT uiMsg,WPARAM wParam,LPARAM lParam)
{
	//UINT wmId, wmEvent;
	switch (uiMsg) 
	{
	HANDLE_MSG(hDlg, WM_INITDIALOG,	OnInitDialog);
	HANDLE_MSG(hDlg, WM_COMMAND,	OnCommand);
	HANDLE_MSG(hDlg, WM_SYSCOMMAND,	OnSysCommand);
	HANDLE_MSG(hDlg, WM_PAINT,		OnPaint);
	HANDLE_MSG(hDlg, WM_DESTROY,	OnDestroy);
	HANDLE_MSG(hDlg, WM_CLOSE,		OnClose);
	HANDLE_MSG(hDlg, WM_DROPFILES,	OnDropFiles);
	HANDLE_MSG(hDlg, WM_NOTIFY,		OnNotify);
	}
	return 0;
}

BOOL OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	hwndMain=hwnd;
	hIcon=LoadIcon(hInst,MAKEINTRESOURCE(IDI_ICON));
	SendMessage(hwnd,WM_SETICON,TRUE,(WPARAM)hIcon);
	hAccel=LoadAccelerators(hInst,MAKEINTRESOURCE(IDC_CRYPTAPI));
	DragAcceptFiles(hwnd,TRUE);
	hSysMenu = GetSystemMenu(hwnd,FALSE);
	if (hSysMenu != NULL)
	{
		AppendMenu(hSysMenu,MF_SEPARATOR,0,0);
		AppendMenu(hSysMenu,MF_STRING | MF_ENABLED,
				ID_ABOUT,szAbout);
	}
	hwndTree=GetDlgItem(hwnd,IDC_TREE1);
	//strcpy(cFnameSave,"EPBytes");
	PEfile=new (PELibrary);
	return FALSE;
}

int CB_CALLCONV callback(unsigned int dwpos)
{
	SendDlgItemMessage(hwndMain,IDC_PROGRESS1,PBM_SETPOS,DWORD(dwpos),0);
	return (1); // continue packing
}

void CreateTrees(HWND hwnd)
{
	int i;
	DWORD dwStyle;
	CHAR* szTemp;
	CHAR* szNum;
	TreeView_DeleteAllItems(hwndTree);
	dwStyle=GetWindowLong(hwndTree,GWL_STYLE);
	dwStyle|=TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS ;
	dwStyle&=~TVS_NOSCROLL;
	dwStyle&=~TVS_NOHSCROLL;
	
	SetWindowLong(hwndTree,GWL_STYLE,dwStyle);
	AddItemToTree(hwndTree, "IMAGE_DOS_HEADER", 1); 
	AddItemToTree(hwndTree, "MS-DOS Stub Program", 1); 
	AddItemToTree(hwndTree, "IMAGE_NT_HEADERS", 1); 
	AddItemToTree(hwndTree, "Signature", 2); 
	AddItemToTree(hwndTree, "IMAGE_FILE_HEADER", 2); 
	AddItemToTree(hwndTree, "IMAGE_OPTIONAL_HEADER", 2); 
	for(i=0;i<14;i++)
	{
		if(PEfile->image_nt_headers->OptionalHeader.DataDirectory[i].VirtualAddress!=0)
		{
			AddItemToTree(hwndTree, szDirectory[i], 3);	
		}
	}
	szTemp=new CHAR[200];
	szNum=new CHAR[8];
	AddItemToTree(hwndTree, "Image Section Headers", 1); 
	for(i=0;i<PEfile->image_nt_headers->FileHeader.NumberOfSections;i++)
	{
		strcpy(szTemp,"IMAGE_SECTION_HEADER 0x");
		itoa(i,szNum,16);
		strcat(szTemp,szNum);
		strcat(szTemp,": ");
		strcat(szTemp,(CHAR*)PEfile->image_section_header[i]->Name);
		AddItemToTree(hwndTree, szTemp, 2);
	}
	AddItemToTree(hwndTree, "Sections", 1); 
	for(i=0;i<PEfile->image_nt_headers->FileHeader.NumberOfSections;i++)
	{
		strcpy(szTemp,"SECTION 0x");
		itoa(i,szNum,16);
		strcat(szTemp,szNum);
		strcat(szTemp,": ");
		strcat(szTemp,(CHAR*)PEfile->image_section_header[i]->Name);
		AddItemToTree(hwndTree, szTemp, 2);
	}
	delete []szTemp;
	delete []szNum;
}

/****************************************************************************
*								OnCommand
*
*  hwnd			Handle of window to which this message applies
*  id			Specifies the identifier of the menu item, 
*				control, or accelerator.
*  hwndCtl		Handle of the control sending the message if the message
*				is from a control, otherwise, this parameter is NULL. 
*  codeNotify	Specifies the notification code if the message is from 
*				a control.
*				This parameter is 1 when the message is from an 
*				accelerator.
*				This parameter is 0 when the message is from a menu.
****************************************************************************/
void OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch (id) 
	{	/* id */
		case IDCLOSE:
			SendMessage(hwnd,WM_CLOSE,NULL,NULL);
			break;
              	                  
		case IDOK:
			EndDialog(hwnd,0);
			break;

		case ID_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hwnd, (DLGPROC)About);
			break;     
/*
		case ID_SUBSYSTEM:
			DialogBox(hInst, (LPCTSTR)IDD_SUBSYSTEM, hwnd, (DLGPROC)SubSystem);
			break;    

		case ID_SECTIONVIEW:
			DialogBox(hInst, (LPCTSTR)IDD_SECTIONVIEW, hwnd, (DLGPROC)SectionView);
			break;    */

		case ID_FILE_OPEN:
			// get a file path
 			cFname[0]=0x00;
			ZeroMemory(&openfn, sizeof(openfn));
			openfn.hwndOwner=GetActiveWindow();
			openfn.lpstrFile=cFname;
			openfn.nMaxFile=sizeof(cFname);
			openfn.lStructSize=sizeof(openfn);
			openfn.lpstrFilter=szFilterOpn; 
			openfn.nFilterIndex=nFilterIndex;
			//openfn.lpstrInitialDir=szCurDir;
			openfn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			if(!GetOpenFileName(&openfn))
			{
				return;
			}
			strcpy(cFnameOpen,cFname);
			SetDlgItemText(hwnd,IDC_FILE_OPEN,cFnameOpen);
			EnableItems(hwnd);
			if(cFnameOpen[0]==0x00) return;
			PEfile->OpenFileName(cFnameOpen);
			//UpdateItems(hwnd);
			bFileOpen=TRUE;
			CreateTrees(hwnd);
			break;

/*		case ID_EPSAVE:
			// get a file path
			if (!bFileOpen) return;
			//cFnameSave[0]=0x00;
			ZeroMemory(&savefn, sizeof(savefn));
			savefn.hwndOwner=GetActiveWindow();
			savefn.lpstrFile=cFnameSave;
			savefn.nMaxFile=sizeof(cFnameSave);
			savefn.lStructSize=sizeof(savefn);
			savefn.lpstrFilter=szFilterSave;
			savefn.nFilterIndex = openfn.nFilterIndex; 
			//savefn.lpstrInitialDir=szCurDir;
			savefn.Flags=OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES | OFN_HIDEREADONLY;
			if(!GetSaveFileName(&savefn))
			{
				return;
			}
			PEfile->SaveEP(cFnameSave);
			//SetDlgItemText(hwnd,IDC_FILE_SAVE,cFnameSave);
			break;
*/
		//case ID_PEIDVEW:
/*		case ID_FIRSTBYTES:
			ZERO(s);
			s.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
							HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETCURRENTOFFSET;
			s.szFilePath   = cFnameOpen;
			s.posCaret.dwOffset=PEfile->ROAddressOfEntryPoint;
			if (!HESpecifySettings(&s))
			{
				MessageBox(0, "File access error !", "Error", MB_ICONERROR);
				break; // ERR
			}
			HEEnterWindowLoop();
			break;*/
		case ID_POPMENU_HEXEDIT:
			ShowComment(hwnd, POPMENU_HEXEDIT);
			break;

		case ID_POPMENU_DATAVIEW:
			ShowComment(hwnd, POPMENU_DATAVIEW);
			break;
	}/* id */
}

/****************************************************************************
*								OnSysCommand
****************************************************************************/
void OnSysCommand(HWND hwnd,UINT cmd, int x, int y)
{
	switch (cmd) 
	{	/* id */
		case ID_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hwnd, (DLGPROC)About);
			break;     
	}/* id */
}

/****************************************************************************
*								OnPaint
*
*  hwnd            Handle of window to which this message applies
*
*  hdrop           Handle of drop
*
****************************************************************************/
void OnDropFiles(HWND hwnd, HDROP hDrop)
{
	DragQueryFile(hDrop,0,cFnameOpen,sizeof(cFnameOpen));
	DragFinish(hDrop);
	SetDlgItemText(hwnd,IDC_FILE_OPEN,cFnameOpen);
	EnableItems(hwnd);
	if(cFnameOpen[0]!=0x00)
	{
		PEfile->OpenFileName(cFnameOpen);
		UpdateItems(hwnd);
		bFileOpen=TRUE;
	}
}

/****************************************************************************
*								OnPaint
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Windows calls this handler when the window needs 
*			       repainting.
****************************************************************************/
void OnPaint (HWND hwnd)
{
    HDC         hdc ;
    PAINTSTRUCT ps ;

	hdc = BeginPaint(hwnd, &ps);
	// TODO: Add any drawing code here...
	EndPaint(hwnd, &ps);
}

/****************************************************************************
*								OnDestroy
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Notification that the specified window is being destroyed.
*                  The window is no longer visible to the user.
****************************************************************************/
void OnDestroy (HWND hwnd)
{
	PostQuitMessage(0);;
}

/****************************************************************************
*								OnClose
*
*  hwnd            Handle of window to which this message applies
*
*  PURPOSE:        Notification that the specified window is being closed.
*
****************************************************************************/
void OnClose(HWND hwnd)
{
	EndDialog(hwnd,0);
}

VOID APIENTRY DisplayContextMenu(HWND hwnd, POINT pt) 
{ 
	HMENU hmenu;            // top-level menu 
	HMENU hmenuTrackPopup;  // shortcut menu 

	// Load the menu resource. 
	if ((hmenu = LoadMenu(hInst, LPCSTR(IDR_POPUPMENU1))) == NULL) return; 

	// TrackPopupMenu cannot display the menu bar so get 
	// a handle to the first shortcut menu. 
	hmenuTrackPopup = GetSubMenu(hmenu, 0); 

	// Display the shortcut menu. Track the right mouse button. 
	TrackPopupMenu(hmenuTrackPopup, 
			TPM_LEFTALIGN | TPM_RIGHTBUTTON, 
			pt.x, pt.y, 0, hwnd, NULL); 

	// Destroy the menu. 
	DestroyMenu(hmenu); 
} 

LRESULT OnNotify(HWND hwnd,WPARAM wParam,NMHDR* nmheader)
{
	//int item;
	HTREEITEM hItem;
	TVITEM tvItem;
	RECT rc;
	char* sztmp;
	POINT   point;
	if(nmheader->hwndFrom==hwndTree)
	{
		switch(nmheader->code)
		{
		/*case NM_DBLCLK :
			//Beep(100,100);
			hItem=TreeView_GetSelection(hwndTree);
			tvItem.mask=TVIF_HANDLE|TVIF_TEXT;
			tvItem.state=TVIS_SELECTED; 
			tvItem.hItem=hItem;
			sztmp= new CHAR[127];
			tvItem.pszText=sztmp;
			tvItem.cchTextMax=127;
			TreeView_GetItem(hwndTree,&tvItem);
			ShowComment(hwnd,sztmp);
			delete []sztmp;
			break;
*/
		case NM_DBLCLK:
			hItem=TreeView_GetSelection(hwndTree);
			tvItem.mask=TVIF_HANDLE|TVIF_TEXT;
			tvItem.state=TVIS_SELECTED; 
			tvItem.hItem=hItem;
			sztmp= new CHAR[127];
			tvItem.pszText=sztmp;
			tvItem.cchTextMax=127;
			TreeView_GetItem(hwndTree,&tvItem);
			TreeView_GetItemRect(hwndTree,hItem,&rc,TRUE);

			memcpy(&point,&nmTreeView.ptDrag,sizeof(POINT));
			ClientToScreen (hwndTree, &point) ;
			point.x+=40;//rc.right-rc.left;
			point.y+=rc.bottom-rc.top;
			DisplayContextMenu(hwnd, point);
			FindSelectItem(hwnd,sztmp);
			delete []sztmp;
			break;

        case TVN_BEGINDRAG:
            //Main_OnBeginDrag is an application-defined function
            //Main_OnBeginDrag(hwndTV, (LPNMTREEVIEW)lParam);
			Beep(100,100);
            break;
		
		case TVN_SELCHANGED:
           	memcpy(&nmTreeView,nmheader,sizeof(NMTREEVIEW));
			break;

		}
	}
	return 0;
}
