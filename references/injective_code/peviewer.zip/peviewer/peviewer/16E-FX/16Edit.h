#pragma once

#include <windows.h>
#include "HexEditWnd.h"
#include "Macros.h"

#include "..\resource.h"

//
// constants
//
#define HEDIT_DLL_NAME         "16Edit.lib"

//
// exported items
//
extern HexEditWnd             HEdit;
extern HINSTANCE              hInst;
