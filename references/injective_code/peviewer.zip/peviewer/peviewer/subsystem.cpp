/* subsystem.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Forum:
   http://yodap.sourceforge.net/forum/

   yodap's Site:
   http://yodap.has.it
   http://yodap.cjb.net
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include <windowsx.h>
#include "SubSystem.h"
#include "main.h"

#include ".\16E-FX\16EditDll.h"
#include ".\16E-FX\macros.h"

//bFileOpen
static BOOL SubSystem_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
static void SubSystem_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);

static HE_SETTINGS  s2;

LRESULT CALLBACK SubSystem(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		HANDLE_MSG(hDlg, WM_INITDIALOG,	SubSystem_OnInitDialog);
		HANDLE_MSG(hDlg, WM_COMMAND,	SubSystem_OnCommand);
	}
	return FALSE;
}

static BOOL SubSystem_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	if (bFileOpen)
	{
		SetDlgItemText(hwnd,IDC_OEP,IntToHex(PEfile->image_nt_headers->OptionalHeader.AddressOfEntryPoint,8,FALSE));
		SetDlgItemText(hwnd,IDC_IMAGEBASE,IntToHex(PEfile->image_nt_headers->OptionalHeader.ImageBase,8,FALSE));
		SetDlgItemText(hwnd,IDC_IMAGESIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.SizeOfImage,8,FALSE));
		SetDlgItemText(hwnd,IDC_CODEBASE,IntToHex(PEfile->image_nt_headers->OptionalHeader.BaseOfCode,8,FALSE));
		SetDlgItemText(hwnd,IDC_DATABASE,IntToHex(PEfile->image_nt_headers->OptionalHeader.BaseOfData,8,FALSE));
		SetDlgItemText(hwnd,IDC_SECTIONALIGN,IntToHex(PEfile->image_nt_headers->OptionalHeader.SectionAlignment,8,FALSE));
		SetDlgItemText(hwnd,IDC_FILEALIGN,IntToHex(PEfile->image_nt_headers->OptionalHeader.FileAlignment,8,FALSE));
		SetDlgItemText(hwnd,IDC_MAGIC,IntToHex(PEfile->image_nt_headers->OptionalHeader.Magic,4,FALSE));
		//
		SetDlgItemText(hwnd,IDC_SUBSYSTEM,IntToHex(PEfile->image_nt_headers->OptionalHeader.Subsystem,4,FALSE));
		SetDlgItemText(hwnd,IDC_SECTIONSNUM,IntToHex(PEfile->image_nt_headers->FileHeader.NumberOfSections,4,FALSE));
		SetDlgItemText(hwnd,IDC_TIMEDATE,IntToHex(PEfile->image_nt_headers->FileHeader.TimeDateStamp,8,FALSE));
		SetDlgItemText(hwnd,IDC_HEADERSSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.SizeOfHeaders,8,FALSE));
		SetDlgItemText(hwnd,IDC_CHARACTER,IntToHex(PEfile->image_nt_headers->FileHeader.Characteristics,4,FALSE));
		SetDlgItemText(hwnd,IDC_CHECKSUM,IntToHex(PEfile->image_nt_headers->OptionalHeader.CheckSum,8,FALSE));
		SetDlgItemText(hwnd,IDC_OPTIONALSIZE,IntToHex(PEfile->image_nt_headers->FileHeader.SizeOfOptionalHeader,4,FALSE));
		SetDlgItemText(hwnd,IDC_RVANUMSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.NumberOfRvaAndSizes,8,FALSE));
		//
		//

		SetDlgItemText(hwnd,IDC_ETRVA,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress,8,FALSE));
		SetDlgItemText(hwnd,IDC_ETSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size,8,FALSE));

		SetDlgItemText(hwnd,IDC_ITRVA,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress,8,FALSE));
		SetDlgItemText(hwnd,IDC_ITSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size,8,FALSE));

		SetDlgItemText(hwnd,IDC_RSRCRVA,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE ].VirtualAddress,8,FALSE));
		SetDlgItemText(hwnd,IDC_RSRCSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE ].Size,8,FALSE));

		SetDlgItemText(hwnd,IDC_TLSRVA,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress,8,FALSE));
		SetDlgItemText(hwnd,IDC_TLSSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size,8,FALSE));

		SetDlgItemText(hwnd,IDC_DEBUGRVA,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].VirtualAddress,8,FALSE));
		SetDlgItemText(hwnd,IDC_DEBUGSIZE,IntToHex(PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DEBUG].Size,8,FALSE));

	}
	return FALSE;
}

/****************************************************************************
*								OnCommand
*
*  hwnd			Handle of window to which this message applies
*  id			Specifies the identifier of the menu item, 
*				control, or accelerator.
*  hwndCtl		Handle of the control sending the message if the message
*				is from a control, otherwise, this parameter is NULL. 
*  codeNotify	Specifies the notification code if the message is from 
*				a control.
*				This parameter is 1 when the message is from an 
*				accelerator.
*				This parameter is 0 when the message is from a menu.
****************************************************************************/
static void SubSystem_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	DWORD dwIT_start;
	DWORD dwIT_size;
	switch (id) 
	{	/* id */
		case IDOK:
		case IDCANCEL:
			EndDialog(hwnd, 0);
			break;
		case ID_RESOURCE_DATA:
			if (bFileOpen)
			{
				dwIT_start=PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE].VirtualAddress;
				dwIT_size=PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_RESOURCE].Size;
				dwIT_start=PEfile->RVA2Offset(dwIT_start);
			
				ZERO(s2);
				s2.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
								HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
				s2.szFilePath   = cFnameOpen;
				s2.dwSelStartOff=dwIT_start;
				s2.dwSelEndOff=dwIT_start+dwIT_size;

				if (!HESpecifySettings(&s2))
				{
					MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
					break; // ERR
				}
				HEEnterWindowLoop();
			}
			break;
		case ID_IMPORT_DATA:
			if (bFileOpen)
			{
				dwIT_start=PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
				dwIT_size=PEfile->image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size;
				dwIT_start=PEfile->RVA2Offset(dwIT_start);
			
				ZERO(s2);
				s2.dwMask       = HE_SET_INPUTFILE | HE_SET_MINIMIZETOTRAY | HE_SET_SAVEWINDOWPOSITION | \
								HE_SET_RESTOREWINDOWPOSITION | HE_SET_ONTOP | HE_SET_SETSELECTION;
				s2.szFilePath   = cFnameOpen;
				s2.dwSelStartOff=dwIT_start;
				s2.dwSelEndOff=dwIT_start+dwIT_size;

				if (!HESpecifySettings(&s2))
				{
					MessageBox(0, "File access error !", "16EditLoader", MB_ICONERROR);
					break; // ERR
				}
				HEEnterWindowLoop();
			}
			break;
	}/* id */
}

