/* dataview2.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Forum:
   http://yodap.sourceforge.net/forum/

   yodap's Site:
   http://yodap.has.it
   http://yodap.cjb.net
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include <windowsx.h>
#include <commctrl.h>
#include "dataview2.h"
#include "main.h"

static HWND		hListSection;
static DWORD	dwStyle;
static DWORD	dwExtendedStyle;

//bFileOpen
static BOOL DataView2_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
static void DataView2_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);

#define C_COLUMNS 3
// InitListViewColumns - adds columns to a list-view
// control. 
// Returns TRUE if successful, or FALSE otherwise. 
// hWndListView - handle to the list-view control. 
static int iWidth[C_COLUMNS ]={65,300,130};
static BOOL DataView2_InitListViewColumns(HWND hWndListView) 
{ 
    char szText[256];     // temporary buffer 
    LVCOLUMN lvc; 
    int iCol; 
	// Initialize the LVCOLUMN structure.
	// The mask specifies that the format, width, text, and
	// subitem members of the structure are valid. 
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 	  
	// Add the columns. 
	for (iCol = 0; iCol < C_COLUMNS; iCol++) 
	{
		lvc.iSubItem = iCol;
		lvc.pszText = szText;
		lvc.cx = iWidth[iCol];     // width of column in pixels
		lvc.fmt = LVCFMT_LEFT;  // left-aligned column
		LoadString(hInst, IDS_D3_FIRSTCOLUMN + iCol, 
			szText, sizeof(szText)/sizeof(szText[0]));
		if (ListView_InsertColumn(hWndListView, iCol,&lvc) == -1) 
			return FALSE; 
	}
	return TRUE; 
} 

// This code snippet adds three items, each with three
// subitems, to a list-view control. 
// hWndListView - handle to the list-view control.
// The following application-specific structure, 
// PETINFO, is used in the snippet.
typedef struct tagSECINFO
{
	char szOffset[10];
	char szRawData[12];
	char szValue[12];
}SECINFO;
static SECINFO SectionInfo;

static BOOL DataView2_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	int i;
	SECINFO SectionInfo;
	LVITEM lvI;
	hListSection=GetDlgItem(hwnd,IDC_LISTSECTION);
	dwStyle = GetWindowLong(hListSection, GWL_STYLE);
	dwStyle|= LVS_REPORT ;
	dwStyle&=~LVS_NOSCROLL;
	SetWindowLong(hListSection, GWL_STYLE, dwStyle);
	DataView2_InitListViewColumns(hListSection);
	//dwExtendedStyle = GetWindowLong(hListSection, GWL_EXSTYLE);
	//dwExtendedStyle = dwExtendedStyle | LVS_EX_UNDERLINEHOT | LVS_EX_FULLROWSELECT | LVS_EX_FLATSB ;
	//SetWindowLong(hListSection, GWL_EXSTYLE, dwExtendedStyle);
	if (bFileOpen)
	{
		// Some code to create the list-view control.
		// Initialize LVITEM members that are common to all
		// items. 
		lvI.mask =  LVIF_TEXT | LVIF_STATE ; 
		lvI.state = 0; 
		lvI.stateMask = 0; 
		// Initialize LVITEM members that are different for each item. 
		for (i = 0; i < PEfile->image_nt_headers->FileHeader.NumberOfSections; i++)
		{
		/*	CopyMemory(SectionInfo.szName,PEfile->image_section_header[i].Name,9);
			CopyMemory(SectionInfo.szVOffset,IntToHex(PEfile->image_section_header[i].VirtualAddress,8,FALSE),9);
			CopyMemory(SectionInfo.szVSize,IntToHex(PEfile->image_section_header[i].Misc.VirtualSize,8,FALSE),9);
			CopyMemory(SectionInfo.szROffset,IntToHex(PEfile->image_section_header[i].PointerToRawData,8,FALSE),9);
			CopyMemory(SectionInfo.szRSize,IntToHex(PEfile->image_section_header[i].SizeOfRawData,8,FALSE),9);
			CopyMemory(SectionInfo.szFlags,IntToHex(PEfile->image_section_header[i].Characteristics,8,FALSE),9);

			lvI.iItem = i;
			lvI.iSubItem = 0;
			lvI.pszText = (LPSTR)&SectionInfo;
			if(ListView_InsertItem(hListSection, &lvI) == -1) return NULL;
			ListView_SetItemText(hListSection,i,1,SectionInfo.szVOffset);
			ListView_SetItemText(hListSection,i,2,SectionInfo.szVSize);
			ListView_SetItemText(hListSection,i,3,SectionInfo.szROffset);
			ListView_SetItemText(hListSection,i,4,SectionInfo.szRSize);
			ListView_SetItemText(hListSection,i,5,SectionInfo.szFlags);*/
		}
	}
	return FALSE;
}

/****************************************************************************
*								OnCommand
*
*  hwnd			Handle of window to which this message applies
*  id			Specifies the identifier of the menu item, 
*				control, or accelerator.
*  hwndCtl		Handle of the control sending the message if the message
*				is from a control, otherwise, this parameter is NULL. 
*  codeNotify	Specifies the notification code if the message is from 
*				a control.
*				This parameter is 1 when the message is from an 
*				accelerator.
*				This parameter is 0 when the message is from a menu.
****************************************************************************/
static void DataView2_OnCommand (HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch (id) 
	{	/* id */
		case IDOK:
		case IDCANCEL:
			EndDialog(hwnd, 0);
			break;
	}/* id */
}

LRESULT CALLBACK DataView2(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		HANDLE_MSG(hDlg, WM_INITDIALOG,	DataView2_OnInitDialog);
		HANDLE_MSG(hDlg, WM_COMMAND,	DataView2_OnCommand);
	}
	return FALSE;
}
