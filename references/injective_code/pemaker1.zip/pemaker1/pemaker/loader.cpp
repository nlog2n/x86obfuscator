/* loader.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Forum:
   http://yodap.sourceforge.net/forum/

   yodap's Site:
   http://yodap.has.it
   http://yodap.cjb.net
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "loader.h"

#ifdef _DEBUG
#define DEBUG_NEW
#endif

__stdcall void DynLoader();
//---------------------------------------------------------
// Thanks FEUERRADER [AHTeam] for idea about using _emit 0! 
//---------------------------------------------------------
// byte ptr		(1 bytes)
#define BYTE_TYPE(x)			__asm _emit x 
// word ptr		(2 bytes)
#define WORD_TYPE(x)			BYTE_TYPE((x>>(0*8))&0xFF)	BYTE_TYPE((x>>(1*8))&0xFF)
// dword ptr	(4 bytes)
#define DWORD_TYPE(x)			BYTE_TYPE((x>>(0*8))&0xFF)	BYTE_TYPE((x>>(1*8))&0xFF)	BYTE_TYPE((x>>(2*8))&0xFF)	BYTE_TYPE((x>>(3*8))&0xFF)
// dword64 ptr	(8 bytes)
#define DWORD64_TYPE(x)			DWORD_TYPE(x)	DWORD_TYPE(x)
// dword64 ptr	(16 bytes)
#define DWORD128_TYPE(x)		DWORD64_TYPE(x)	DWORD64_TYPE(x)
//---------------------------------------------------------
#define BB(x)					__asm _emit x 
#define DB						BYTE_TYPE(0xCC)
#define __RANDOM_CODE1__		DWORD64_TYPE(0X90909090) // Reserve for random code generation
#define __JMP_API				BYTE_TYPE(0xFF)	BYTE_TYPE(0x25)

//----------------------------------------------------------------
__stdcall void DynLoader()
{
_asm
{
//----------------------------------
	DWORD_TYPE(DYN_LOADER_START_MAGIC)
//----------------------------------
	MOV EAX,01012475h // << Original OEP
	JMP EAX
//----------------------------------
	DWORD_TYPE(DYN_LOADER_END_MAGIC)
//----------------------------------
}
}
//----------------------------------------------------------------