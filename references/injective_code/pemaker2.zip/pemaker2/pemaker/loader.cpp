/* loader.cpp --

   This file is part of the "PE Maker".

   Copyright (C) 2005-2006 Ashkbiz Danehkar
   All Rights Reserved.

   "PE Maker" library are free software; you can redistribute them
   and/or modify them under the terms of the GNU General Public License as
   published by the Free Software Foundation.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYRIGHT.TXT.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   yodap's Forum:
   http://yodap.sourceforge.net/forum/

   yodap's Site:
   http://yodap.has.it
   http://yodap.cjb.net
   http://yodap.sourceforge.net

   Ashkbiz Danehkar
   <ashkbiz@yahoo.com>
*/
#include "stdafx.h"
#include "loader.h"

#ifdef _DEBUG
#define DEBUG_NEW
#endif

__stdcall void DynLoader();
//---------------------------------------------------------
// Thanks FEUERRADER [AHTeam] for idea about using _emit 0! 
//---------------------------------------------------------
// byte ptr		(1 bytes)
#define BYTE_TYPE(x)			__asm _emit x 
// word ptr		(2 bytes)
#define WORD_TYPE(x)			BYTE_TYPE((x>>(0*8))&0xFF)	BYTE_TYPE((x>>(1*8))&0xFF)
// dword ptr	(4 bytes)
#define DWORD_TYPE(x)			BYTE_TYPE((x>>(0*8))&0xFF)	BYTE_TYPE((x>>(1*8))&0xFF)	BYTE_TYPE((x>>(2*8))&0xFF)	BYTE_TYPE((x>>(3*8))&0xFF)
// dword64 ptr	(8 bytes)
#define DWORD64_TYPE(x)			DWORD_TYPE(x)	DWORD_TYPE(x)
// dword64 ptr	(16 bytes)
#define DWORD128_TYPE(x)		DWORD64_TYPE(x)	DWORD64_TYPE(x)
//---------------------------------------------------------
#define BB(x)					__asm _emit x 
#define DB						BYTE_TYPE(0xCC)
#define __RANDOM_CODE1__		DWORD64_TYPE(0X90909090) // Reserve for random code generation
#define __JMP_API				BYTE_TYPE(0xFF)	BYTE_TYPE(0x25)

//----------------------------------------------------------------
//----------------------------------------------------------------
__stdcall void DynLoader()
{
_asm
{
//----------------------------------
	DWORD_TYPE(DYN_LOADER_START_MAGIC)
//----------------------------------
Main_0:
	PUSHAD	// Save the registers context in stack
	CALL Main_1
Main_1:	
	POP EBP
	SUB EBP,OFFSET Main_1 // Get Base EBP
	MOV EAX,DWORD PTR [EBP+_RO_dwImageBase]
	ADD EAX,DWORD PTR [EBP+_RO_dwOrgEntryPoint]
	MOV DWORD PTR [ESP+10h],EAX	// pStack.Ebx <- EAX
	LEA EAX,[EBP+_except_handler1_OEP_Jump]
	MOV DWORD PTR [ESP+1Ch],EAX	// pStack.Eax <- EAX
	POPAD	// Restore the first registers context from stack
	//----------------------------------------------------
  	// the structured exception handler (SEH) installation 
	PUSH EAX
	XOR  EAX, EAX
	PUSH DWORD PTR FS:[0]		// NT_TIB32.ExceptionList
	MOV DWORD PTR FS:[0],ESP	// NT_TIB32.ExceptionList <-ESP
	//----------------------------------------------------
	// the raise a INT 3 exception
	DWORD_TYPE(0xCCCCCCCC)
//--------------------------------------------------------
// -------- exception handler expression filter ----------
_except_handler1_OEP_Jump:
	PUSH EBP
	MOV EBP,ESP
	//------------------------------
	MOV EAX,DWORD PTR SS:[EBP+010h]	// PCONTEXT: pContext <- EAX
	//==============================
	PUSH EDI
	// restore original SEH
	MOV EDI,DWORD PTR DS:[EAX+0C4h]	// pContext.Esp
	PUSH DWORD PTR DS:[EDI]
	POP DWORD PTR FS:[0]
	ADD DWORD PTR DS:[EAX+0C4h],8	// pContext.Esp
	//------------------------------
	// set the Eip to the OEP
	MOV EDI,DWORD PTR DS:[EAX+0A4h] // EAX <- pContext.Ebx
	MOV DWORD PTR DS:[EAX+0B8h],EDI // pContext.Eip <- EAX
	//------------------------------
	POP EDI
	//==============================
	MOV EAX, EXCEPTION_CONTINUE_SEARCH
	LEAVE
	RETN
//----------------------------------
	DWORD_TYPE(DYN_LOADER_START_DATA1)
//----------------------------------
_RO_dwImageBase:				DWORD_TYPE(0xCCCCCCCC)
_RO_dwOrgEntryPoint:			DWORD_TYPE(0xCCCCCCCC)
//----------------------------------
	DWORD_TYPE(DYN_LOADER_END_MAGIC)
//----------------------------------
}
}
/*__stdcall void DynLoader()
{
_asm
{
//----------------------------------
	DWORD_TYPE(DYN_LOADER_START_MAGIC)
//----------------------------------
Main_0:
	PUSHAD
	// get base ebp
	CALL Main_1
Main_1:	
	POP EBP
	SUB EBP,OFFSET Main_1
	MOV EAX,DWORD PTR [EBP+_RO_dwImageBase]
	ADD EAX,DWORD PTR [EBP+_RO_dwOrgEntryPoint]
	PUSH EAX
	RETN // >> JMP to Original OEP
//----------------------------------
	DWORD_TYPE(DYN_LOADER_START_DATA1)
//----------------------------------
_RO_dwImageBase:				DWORD_TYPE(0xCCCCCCCC)
_RO_dwOrgEntryPoint:			DWORD_TYPE(0xCCCCCCCC)
//----------------------------------
	DWORD_TYPE(DYN_LOADER_END_MAGIC)
//----------------------------------
}
}*/
//----------------------------------------------------------------
